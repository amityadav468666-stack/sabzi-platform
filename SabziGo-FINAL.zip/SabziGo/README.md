# SabziGo
Complete starter project: Customer, Shopkeeper, Admin, Products, Cart, Orders, Firebase Auth/Firestore.

## शुरू करने के लिए
1. Firebase Console में Web App बनाकर `js/firebase.js` में config भरें।
2. Authentication > Sign-in method > Email/Password चालू करें।
3. Firestore Database बनाएँ।
4. `firestore.rules` को Firestore Rules में publish करें।
5. पहले admin user को Firebase Authentication में बनाएँ और Firestore `users/{UID}` document में `role: "admin"` सेट करें।
6. GitHub/Cloudflare Pages पर project deploy करें।

## Online Payment
`orders.js` अभी payment status और order flow का सुरक्षित placeholder बनाता है। वास्तविक Razorpay/Stripe/UPI gateway के लिए secret key को frontend में कभी न रखें; server/Cloud Function से payment order बनाकर signature/payment verify करें।
