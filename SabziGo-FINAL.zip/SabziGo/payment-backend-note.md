# Online Payment — अगला integration
Frontend में secret payment key नहीं रखनी है। Production में Firebase Cloud Functions/Cloud Run जैसे trusted backend से:
1. Payment gateway order create करें।
2. Gateway checkout खोलें।
3. Backend पर payment signature verify करें।
4. Verify होने के बाद Firestore order का paymentStatus = paid करें।
5. Webhook से final payment state synchronize करें।

इस starter project में जानबूझकर fake payment success नहीं बनाया गया है।